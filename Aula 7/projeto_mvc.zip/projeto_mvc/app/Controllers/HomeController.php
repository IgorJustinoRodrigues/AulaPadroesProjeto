<?php
namespace App\Controllers;

// app/Controllers/HomeController.php
class HomeController {
    public function index() {
        require '../app/Views/index.php';
    }
}
