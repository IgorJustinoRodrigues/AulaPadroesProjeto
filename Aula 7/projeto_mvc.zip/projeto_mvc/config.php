<?php
return [
    'host' => 'localhost',
    'db' => 'projeto_mvc',
    'user' => 'root', // Troque pelo usuário do seu banco de dados
    'password' => '' // Troque pela senha do seu banco de dados
];
